import { chromium } from "playwright";

const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
try {
  const page = await browser.newPage({
    viewport: { width: 1200, height: 630 },
    deviceScaleFactor: 2,
  });
  await page.goto("file:///workspace/.grok/og-card.html", { waitUntil: "load" });
  const metrics = await page.evaluate(() => {
    const box = (sel) => {
      const el = document.querySelector(sel);
      const r = el.getBoundingClientRect();
      const cs = getComputedStyle(el);
      return {
        x: +r.x.toFixed(1),
        y: +r.y.toFixed(1),
        w: +r.width.toFixed(1),
        h: +r.height.toFixed(1),
        right: +r.right.toFixed(1),
        bottom: +r.bottom.toFixed(1),
        font: cs.fontFamily,
        size: cs.fontSize,
      };
    };
    return { h1: box("h1"), p: box("p"), spark: box(".spark"), status: box(".status") };
  });
  console.log(JSON.stringify(metrics, null, 2));
  await page.screenshot({ path: "/workspace/.grok/og-raw.png", type: "png" });
} finally {
  await browser.close();
}
