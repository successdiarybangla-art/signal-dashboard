import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { r as pairByYahoo } from "./pairs-BQJWIMPV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/market-api-Ae_GXDQE.js
var cache = /* @__PURE__ */ new Map();
function normalize(raw) {
	if (!raw || typeof raw !== "object") return null;
	const result = raw.chart?.result?.[0];
	if (!result || typeof result !== "object") return null;
	const row = result;
	const times = row.timestamp ?? [];
	const quote = row.indicators?.quote?.[0];
	if (!quote) return null;
	const byTime = /* @__PURE__ */ new Map();
	let live = 0;
	let liveAt = 0;
	for (let i = 0; i < times.length; i++) {
		const open = quote.open?.[i];
		const high = quote.high?.[i];
		const low = quote.low?.[i];
		const close = quote.close?.[i];
		if (open == null || high == null || low == null || close == null) continue;
		if (![
			open,
			high,
			low,
			close
		].every(Number.isFinite)) continue;
		if (times[i] % 60 !== 0) {
			if (times[i] >= liveAt) {
				live = close;
				liveAt = times[i];
			}
			continue;
		}
		byTime.set(times[i], {
			time: times[i],
			open,
			high,
			low,
			close
		});
	}
	const candles = [...byTime.values()].sort((a, b) => a.time - b.time).slice(-90);
	if (candles.length < 30) return null;
	const meta = row.meta?.regularMarketPrice;
	return {
		candles,
		price: live || (typeof meta === "number" && Number.isFinite(meta) ? meta : candles[candles.length - 1].close)
	};
}
var getMarket_createServerFn_handler = createServerRpc({
	id: "6644f97bb3d43134626c764eddfb8972a3d7dc2fa2687f06ca29f92c274e3607",
	name: "getMarket",
	filename: "src/lib/market-api.ts"
}, (opts) => getMarket.__executeServer(opts));
var getMarket = createServerFn({ method: "POST" }).validator((input) => {
	const symbol = input?.symbol;
	if (!pairByYahoo(symbol)) throw new Error("Unknown pair");
	return { symbol };
}).handler(getMarket_createServerFn_handler, async ({ data }) => {
	const hit = cache.get(data.symbol);
	if (hit && Date.now() - hit.at < 1500) return hit.body;
	try {
		const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(data.symbol)}?interval=1m&range=1d&includePrePost=true`;
		const response = await fetch(url, {
			headers: {
				"user-agent": "Mozilla/5.0",
				accept: "application/json"
			},
			signal: AbortSignal.timeout(12e3)
		});
		if (!response.ok) return {
			ok: false,
			error: "মার্কেট ডেটা আসেনি। আবার চেষ্টা হচ্ছে।"
		};
		const parsed = normalize(await response.json());
		if (!parsed) return {
			ok: false,
			error: "যথেষ্ট ক্যান্ডেল পাওয়া যায়নি।"
		};
		const body = {
			ok: true,
			symbol: data.symbol,
			candles: parsed.candles,
			price: parsed.price,
			serverNow: Date.now()
		};
		cache.set(data.symbol, {
			at: Date.now(),
			body
		});
		return body;
	} catch {
		return {
			ok: false,
			error: "মার্কেট ডেটা আসেনি। আবার চেষ্টা হচ্ছে।"
		};
	}
});
//#endregion
export { getMarket_createServerFn_handler };
