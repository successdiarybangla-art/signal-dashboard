//#region node_modules/.nitro/vite/services/ssr/assets/pairs-BQJWIMPV.js
var PAIRS = [
	{
		id: "eurusd",
		label: "EUR/USD",
		yahoo: "EURUSD=X",
		kind: "ফরেক্স"
	},
	{
		id: "gbpusd",
		label: "GBP/USD",
		yahoo: "GBPUSD=X",
		kind: "ফরেক্স"
	},
	{
		id: "usdjpy",
		label: "USD/JPY",
		yahoo: "USDJPY=X",
		kind: "ফরেক্স"
	},
	{
		id: "audusd",
		label: "AUD/USD",
		yahoo: "AUDUSD=X",
		kind: "ফরেক্স"
	},
	{
		id: "btcusd",
		label: "BTC/USD",
		yahoo: "BTC-USD",
		kind: "ক্রিপ্টো"
	},
	{
		id: "ethusd",
		label: "ETH/USD",
		yahoo: "ETH-USD",
		kind: "ক্রিপ্টো"
	},
	{
		id: "gold",
		label: "Gold",
		yahoo: "GC=F",
		kind: "ফিউচার"
	}
];
var byId = new Map(PAIRS.map((pair) => [pair.id, pair]));
var byYahoo = new Map(PAIRS.map((pair) => [pair.yahoo, pair]));
function pairById(id) {
	return byId.get(id) ?? PAIRS[0];
}
function pairByYahoo(symbol) {
	return byYahoo.get(symbol);
}
//#endregion
export { pairById as n, pairByYahoo as r, PAIRS as t };
