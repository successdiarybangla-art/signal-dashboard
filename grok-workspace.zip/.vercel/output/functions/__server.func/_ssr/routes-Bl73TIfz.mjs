import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as pairById, r as pairByYahoo, t as PAIRS } from "./pairs-BQJWIMPV.mjs";
import { n as ArrowUpRight, r as ArrowDownRight } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { n as Area, r as ResponsiveContainer, t as AreaChart } from "../_libs/recharts+[...].mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bl73TIfz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getMarket = createServerFn({ method: "POST" }).validator((input) => {
	const symbol = input?.symbol;
	if (!pairByYahoo(symbol)) throw new Error("Unknown pair");
	return { symbol };
}).handler(createSsrRpc("6644f97bb3d43134626c764eddfb8972a3d7dc2fa2687f06ca29f92c274e3607"));
function cleanToken(token) {
	const value = token.trim();
	if (!/^\d{6,12}:[A-Za-z0-9_-]{20,}$/.test(value)) return null;
	return value;
}
function cleanChat(chatId) {
	const value = chatId.trim();
	if (!/^-?\d{1,20}$/.test(value)) return null;
	return value;
}
var sendTelegram = createServerFn({ method: "POST" }).validator((input) => {
	const token = cleanToken(input?.token ?? "");
	const chatId = cleanChat(input?.chatId ?? "");
	const text = (input?.text ?? "").slice(0, 3500);
	if (!token) throw new Error("টোকেন ঠিক না");
	if (!chatId) throw new Error("চ্যাট আইডি ঠিক না");
	if (!text) throw new Error("খালি মেসেজ");
	return {
		token,
		chatId,
		text
	};
}).handler(createSsrRpc("7e1aff2ed5e393c371117bf79fa51ea3acee101efd5245e9b347c8e7c8d6803d"));
var findTelegramChat = createServerFn({ method: "POST" }).validator((input) => {
	const token = cleanToken(input?.token ?? "");
	if (!token) throw new Error("টোকেন ঠিক না");
	return { token };
}).handler(createSsrRpc("33fec8b1e112bd9cf682c6102569cb09c65ca659f7d7113353136bff6b5f5581"));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function ema(values, period) {
	const k = 2 / (period + 1);
	const out = [];
	let prev = 0;
	let seed = 0;
	for (let i = 0; i < period && i < values.length; i++) seed += values[i];
	seed /= Math.min(period, values.length);
	for (let i = 0; i < values.length; i++) {
		if (i < period - 1) {
			out.push(NaN);
			continue;
		}
		if (i === period - 1) {
			prev = seed;
			out.push(prev);
			continue;
		}
		prev = values[i] * k + prev * (1 - k);
		out.push(prev);
	}
	return out;
}
function rsi(closes, period = 14) {
	if (closes.length < period + 1) return null;
	let gain = 0;
	let loss = 0;
	for (let i = 1; i <= period; i++) {
		const delta = closes[i] - closes[i - 1];
		if (delta >= 0) gain += delta;
		else loss -= delta;
	}
	let avgGain = gain / period;
	let avgLoss = loss / period;
	for (let i = period + 1; i < closes.length; i++) {
		const delta = closes[i] - closes[i - 1];
		const up = delta > 0 ? delta : 0;
		const down = delta < 0 ? -delta : 0;
		avgGain = (avgGain * (period - 1) + up) / period;
		avgLoss = (avgLoss * (period - 1) + down) / period;
	}
	if (avgLoss === 0) return 100;
	return 100 - 100 / (1 + avgGain / avgLoss);
}
function analyze(closed) {
	if (closed.length < 30) return null;
	const closes = closed.map((candle) => candle.close);
	const last = closes.length - 1;
	const price = closes[last];
	if (!Number.isFinite(price) || price === 0) return null;
	const ema9 = ema(closes, 9);
	const ema21 = ema(closes, 21);
	const fast = ema9[last];
	const slow = ema21[last];
	const fastPrev = ema9[last - 3];
	if (![
		fast,
		slow,
		fastPrev
	].every(Number.isFinite)) return null;
	const gapVote = clamp((fast - slow) / price / 4e-4, -1, 1);
	const slopeVote = clamp((fast - fastPrev) / price / 15e-5, -1, 1);
	const rsiValue = rsi(closes, 14) ?? 50;
	let rsiVote = clamp((rsiValue - 50) / 25, -1, 1);
	if (rsiValue >= 78) rsiVote = -.35;
	if (rsiValue <= 22) rsiVote = .35;
	let impulse = 0;
	for (let i = 0; i < 4; i++) {
		const candle = closed[last - i];
		impulse += (candle.close - candle.open) / price;
	}
	const impulseVote = clamp(impulse / 5e-4, -1, 1);
	const structVote = clamp((price - closes[last - 8]) / price / 8e-4, -1, 1);
	const factors = [
		{
			label: "EMA",
			vote: gapVote,
			note: Math.abs(gapVote) < .08 ? "EMA9 আর EMA21 প্রায় একসাথে" : gapVote > 0 ? "EMA9, EMA21-এর উপরে" : "EMA9, EMA21-এর নিচে"
		},
		{
			label: "ঢাল",
			vote: slopeVote,
			note: Math.abs(slopeVote) < .08 ? "EMA9 প্রায় সমান" : slopeVote > 0 ? "EMA9 উপরে উঠছে" : "EMA9 নিচে নামছে"
		},
		{
			label: "RSI",
			vote: rsiVote,
			note: rsiValue >= 78 ? `RSI ${Math.round(rsiValue)}, অতিরিক্ত কেনা` : rsiValue <= 22 ? `RSI ${Math.round(rsiValue)}, অতিরিক্ত বিক্রি` : rsiVote >= 0 ? `RSI ${Math.round(rsiValue)}, বায়ার দিক` : `RSI ${Math.round(rsiValue)}, সেলার দিক`
		},
		{
			label: "বডি",
			vote: impulseVote,
			note: Math.abs(impulseVote) < .08 ? "শেষ ক্যান্ডেলের বডি মিশ্র" : impulseVote > 0 ? "শেষ ক্যান্ডেলগুলোর বডি উপরে" : "শেষ ক্যান্ডেলগুলোর বডি নিচে"
		},
		{
			label: "কাঠামো",
			vote: structVote,
			note: Math.abs(structVote) < .08 ? "কয়েক মিনিটে দাম প্রায় একই" : structVote > 0 ? "কয়েক মিনিটের হাইয়ার ক্লোজ" : "কয়েক মিনিটের লোয়ার ক্লোজ"
		}
	];
	const weights = [
		.28,
		.2,
		.22,
		.18,
		.12
	];
	const score = factors.reduce((sum, factor, index) => sum + factor.vote * weights[index], 0);
	const direction = score >= 0 ? "CALL" : "PUT";
	const sign = Math.sign(score) || 1;
	const aligned = factors.filter((factor) => Math.sign(factor.vote) === sign && Math.abs(factor.vote) >= .2);
	const confidence = clamp(Math.round(50 + Math.abs(score) * 48), 50, 92);
	const reason = `${[...factors].sort((a, b) => Math.abs(b.vote) - Math.abs(a.vote)).slice(0, 3).map((factor) => factor.note).join("। ")}।`;
	return {
		direction,
		confidence,
		tradable: aligned.length >= 3 && Math.abs(score) >= .12,
		reason,
		factors
	};
}
function floorMinute(sec) {
	return sec - sec % 60;
}
function formatClock(ms) {
	return new Intl.DateTimeFormat("en-GB", {
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit",
		hour12: false
	}).format(new Date(ms));
}
function formatHM(sec) {
	return new Intl.DateTimeFormat("en-GB", {
		hour: "2-digit",
		minute: "2-digit",
		hour12: false
	}).format(/* @__PURE__ */ new Date(sec * 1e3));
}
function priceDigits(sample) {
	const abs = Math.abs(sample);
	if (abs >= 1e3) return 2;
	if (abs >= 100) return 3;
	if (abs >= 10) return 4;
	return 5;
}
function formatPrice(value, sample) {
	const digits = priceDigits(sample);
	return value.toLocaleString("en-US", {
		minimumFractionDigits: digits,
		maximumFractionDigits: digits
	});
}
function formatPnl(value) {
	return `${value > 0 ? "+" : ""}${value.toFixed(2)}`;
}
function isPrintSeries(candles) {
	const recent = candles.slice(-12);
	if (recent.length < 6) return false;
	return recent.filter((candle) => candle.high === candle.low).length / recent.length >= .75;
}
function finishTrade(trade, entry, exit) {
	const eps = Math.max(Math.abs(entry) * 1e-8, 1e-8);
	let result;
	if (Math.abs(exit - entry) <= eps) result = "draw";
	else if (trade.direction === "CALL") result = exit > entry ? "win" : "loss";
	else result = exit < entry ? "win" : "loss";
	const pnl = result === "win" ? trade.stake * trade.payoutPct / 100 : result === "loss" ? -trade.stake : 0;
	return {
		...trade,
		entryPrice: entry,
		exitPrice: exit,
		result,
		pnl
	};
}
function settleAgainstBook(trade, candles, nowSec, livePrice) {
	if (trade.result !== "pending") return trade;
	if (nowSec - trade.entryTime > 180 && !candles.some((candle) => candle.time >= trade.entryTime - 60)) return {
		...trade,
		result: "draw",
		pnl: 0,
		signalSent: true,
		resultSent: true
	};
	if (isPrintSeries(candles)) {
		const prev = candles.find((candle) => candle.time === trade.entryTime - 60);
		const cur = candles.find((candle) => candle.time === trade.entryTime);
		const entry = prev?.close ?? trade.entryPrice ?? livePrice;
		if (!cur) {
			if (nowSec - trade.entryTime > 180) return {
				...trade,
				entryPrice: entry,
				result: "draw",
				pnl: 0,
				signalSent: true,
				resultSent: true
			};
			return {
				...trade,
				entryPrice: entry
			};
		}
		if (!(candles.some((candle) => candle.time > trade.entryTime) || nowSec >= trade.entryTime + 70)) return {
			...trade,
			entryPrice: entry
		};
		return finishTrade(trade, entry, cur.close);
	}
	const cur = candles.find((candle) => candle.time === trade.entryTime);
	if (!cur) {
		if (nowSec - trade.entryTime > 180) return {
			...trade,
			result: "draw",
			pnl: 0,
			signalSent: true,
			resultSent: true
		};
		return {
			...trade,
			entryPrice: trade.entryPrice ?? livePrice
		};
	}
	if (!(candles.some((candle) => candle.time > cur.time) || nowSec >= trade.entryTime + 70)) return {
		...trade,
		entryPrice: cur.open
	};
	return finishTrade(trade, cur.open, cur.close);
}
function signalText(trade) {
	return [
		"EKMIN · 1 MIN",
		trade.label,
		trade.direction,
		`Entry time: ${formatHM(trade.entryTime)}`,
		`Confidence: ${trade.confidence}%`,
		`Reason: ${trade.reason}`,
		"",
		"১ মিনিট পর রেজাল্ট অটো আসবে।",
		"Quotex-এ অর্ডার নিজে দিতে হবে।"
	].join("\n");
}
function resultText(trade) {
	const word = trade.result === "win" ? "WIN" : trade.result === "loss" ? "LOSS" : "DRAW";
	const sample = trade.entryPrice ?? trade.exitPrice ?? 1;
	const entry = trade.entryPrice == null ? "—" : formatPrice(trade.entryPrice, sample);
	const exit = trade.exitPrice == null ? "—" : formatPrice(trade.exitPrice, sample);
	return [
		"EKMIN · RESULT",
		`${trade.label} ${trade.direction}`,
		word,
		`${entry} → ${exit}`,
		trade.pnl == null ? "" : `P/L: ${formatPnl(trade.pnl)}`
	].filter(Boolean).join("\n");
}
function sessionStats(trades) {
	const done = trades.filter((trade) => trade.result !== "pending");
	const wins = done.filter((trade) => trade.result === "win").length;
	const losses = done.filter((trade) => trade.result === "loss").length;
	const draws = done.filter((trade) => trade.result === "draw").length;
	const pnl = done.reduce((sum, trade) => sum + (trade.pnl ?? 0), 0);
	const decided = wins + losses;
	let streak = 0;
	let streakKind = null;
	for (const trade of done) {
		if (trade.result !== "win" && trade.result !== "loss") continue;
		if (streakKind == null) {
			streakKind = trade.result;
			streak = 1;
			continue;
		}
		if (trade.result === streakKind) streak += 1;
		else break;
	}
	return {
		wins,
		losses,
		draws,
		pnl,
		rate: decided === 0 ? null : wins / decided,
		streak,
		streakKind,
		decided
	};
}
function sameBook(left, right) {
	if (left.length !== right.length) return false;
	for (let i = 0; i < left.length; i++) if (left[i] !== right[i]) return false;
	return true;
}
function bookTrades(trades, candles, nowSec, livePrice) {
	return trades.map((trade) => settleAgainstBook(trade, candles, nowSec, livePrice));
}
function openTrade(trades, pair, analysis, entryTime, entryPrice, stake, payoutPct, notify) {
	if (trades.some((trade) => trade.result === "pending")) return trades;
	if (trades.some((trade) => trade.entryTime === entryTime && trade.pairId === pair.id)) return trades;
	return [{
		id: `${pair.id}-${entryTime}`,
		pairId: pair.id,
		label: pair.label,
		direction: analysis.direction,
		confidence: analysis.confidence,
		reason: analysis.reason,
		entryTime,
		entryPrice,
		exitPrice: null,
		result: "pending",
		stake,
		payoutPct,
		pnl: null,
		notify,
		signalSent: false,
		resultSent: false
	}, ...trades].slice(0, 180);
}
function maybeAuto(state, snap, nowSec) {
	let trades = bookTrades(state.trades, snap.candles, nowSec, snap.price);
	if (!state.auto) return trades;
	const currentStart = floorMinute(nowSec);
	if (nowSec - currentStart > 20) return trades;
	if (snap.serverNow < currentStart * 1e3) return trades;
	if (snap.symbol !== pairById(state.pairId).yahoo) return trades;
	const latest = snap.candles[snap.candles.length - 1];
	if (!latest || nowSec - latest.time > 180) return trades;
	const analysis = analyze(snap.candles.filter((candle) => candle.time < currentStart));
	if (!analysis || !analysis.tradable || analysis.confidence < state.minConfidence) return trades;
	const forming = snap.candles.find((candle) => candle.time === currentStart);
	const prev = snap.candles.find((candle) => candle.time === currentStart - 60);
	const entryPrice = isPrintSeries(snap.candles) ? prev?.close ?? snap.price : forming?.open ?? snap.price;
	return openTrade(trades, pairById(state.pairId), analysis, currentStart, entryPrice, state.stake, state.payoutPct, state.telegramOn && state.telegramToken.trim() !== "" && state.telegramChatId.trim() !== "");
}
var useDesk = create()(persist((set, get) => ({
	pairId: "eurusd",
	auto: true,
	minConfidence: 62,
	stake: 1,
	payoutPct: 80,
	telegramToken: "",
	telegramChatId: "",
	telegramOn: false,
	trades: [],
	snap: null,
	error: null,
	skewMs: 0,
	telegramNote: "",
	confirmClear: false,
	setPair: (id) => set({
		pairId: pairById(id).id,
		snap: null,
		error: null
	}),
	patch: (partial) => set((state) => ({
		...partial,
		minConfidence: partial.minConfidence == null ? state.minConfidence : Math.round(Math.min(90, Math.max(50, partial.minConfidence))),
		stake: partial.stake == null ? state.stake : Number.isFinite(partial.stake) && partial.stake > 0 ? Math.min(partial.stake, 1e5) : state.stake,
		payoutPct: partial.payoutPct == null ? state.payoutPct : Number.isFinite(partial.payoutPct) ? Math.min(100, Math.max(1, Math.round(partial.payoutPct))) : state.payoutPct
	})),
	ingest: (snap) => set((state) => {
		return {
			snap,
			skewMs: snap.serverNow - Date.now(),
			error: null,
			trades: maybeAuto(state, snap, Math.floor(snap.serverNow / 1e3))
		};
	}),
	tick: () => set((state) => {
		if (!state.snap) return state;
		const nowSec = Math.floor((Date.now() + state.skewMs) / 1e3);
		if (Date.now() + state.skewMs - state.snap.serverNow > 2e4) return state;
		const trades = maybeAuto(state, state.snap, nowSec);
		if (sameBook(trades, state.trades)) return state;
		return { trades };
	}),
	takeSignal: () => {
		const state = get();
		if (!state.snap) return {
			ok: false,
			error: "দাম এখনো আসেনি"
		};
		const nowSec = Math.floor((Date.now() + state.skewMs) / 1e3);
		const currentStart = floorMinute(nowSec);
		if (nowSec - currentStart > 20) return {
			ok: false,
			error: "এন্ট্রি উইন্ডো শেষ। পরের মিনিট নাও।"
		};
		if (state.snap.serverNow < currentStart * 1e3) return {
			ok: false,
			error: "এই মিনিটের দাম এখনো লক হয়নি"
		};
		const latest = state.snap.candles[state.snap.candles.length - 1];
		if (!latest || nowSec - latest.time > 180) return {
			ok: false,
			error: "এই পেয়ারে লাইভ ক্যান্ডেল নেই"
		};
		if (state.trades.some((trade) => trade.result === "pending")) return {
			ok: false,
			error: "আগের ট্রেড এখনো চলছে"
		};
		const pair = pairById(state.pairId);
		const analysis = analyze(state.snap.candles.filter((candle) => candle.time < currentStart));
		if (!analysis) return {
			ok: false,
			error: "সিগন্যাল বের হয়নি"
		};
		const forming = state.snap.candles.find((candle) => candle.time === currentStart);
		const prev = state.snap.candles.find((candle) => candle.time === currentStart - 60);
		const entryPrice = isPrintSeries(state.snap.candles) ? prev?.close ?? state.snap.price : forming?.open ?? state.snap.price;
		set({ trades: openTrade(state.trades, pair, analysis, currentStart, entryPrice, state.stake, state.payoutPct, state.telegramOn && state.telegramToken.trim() !== "" && state.telegramChatId.trim() !== "") });
		return { ok: true };
	},
	markSent: (id, kind) => set((state) => ({ trades: state.trades.map((trade) => trade.id !== id ? trade : kind === "signal" ? {
		...trade,
		signalSent: true
	} : {
		...trade,
		resultSent: true
	}) })),
	clearTrades: () => set({
		trades: [],
		confirmClear: false
	})
}), {
	name: "ekmin-desk",
	skipHydration: true,
	partialize: (state) => ({
		pairId: state.pairId,
		auto: state.auto,
		minConfidence: state.minConfidence,
		stake: state.stake,
		payoutPct: state.payoutPct,
		telegramToken: state.telegramToken,
		telegramChatId: state.telegramChatId,
		telegramOn: state.telegramOn,
		trades: state.trades
	})
}));
function readPreview(snap, nowSec) {
	if (!snap) return null;
	const currentStart = floorMinute(nowSec);
	const closed = snap.candles.filter((candle) => candle.time < currentStart);
	return analyze(closed.length >= 30 ? closed : snap.candles.slice(0, -1));
}
function marketIsStale(snap, nowSec) {
	if (!snap) return false;
	const latest = snap.candles[snap.candles.length - 1];
	return !latest || nowSec - latest.time > 180;
}
function Desk() {
	const pairId = useDesk((state) => state.pairId);
	const auto = useDesk((state) => state.auto);
	const minConfidence = useDesk((state) => state.minConfidence);
	const stake = useDesk((state) => state.stake);
	const payoutPct = useDesk((state) => state.payoutPct);
	const telegramToken = useDesk((state) => state.telegramToken);
	const telegramChatId = useDesk((state) => state.telegramChatId);
	const telegramOn = useDesk((state) => state.telegramOn);
	const trades = useDesk((state) => state.trades);
	const snap = useDesk((state) => state.snap);
	const error = useDesk((state) => state.error);
	const skewMs = useDesk((state) => state.skewMs);
	const telegramNote = useDesk((state) => state.telegramNote);
	const confirmClear = useDesk((state) => state.confirmClear);
	const setPair = useDesk((state) => state.setPair);
	const patch = useDesk((state) => state.patch);
	const takeSignal = useDesk((state) => state.takeSignal);
	const markSent = useDesk((state) => state.markSent);
	const clearTrades = useDesk((state) => state.clearTrades);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [now, setNow] = (0, import_react.useState)(0);
	const [takeNote, setTakeNote] = (0, import_react.useState)("");
	const [telegramBusy, setTelegramBusy] = (0, import_react.useState)(null);
	const inflight = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const retryAt = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	(0, import_react.useEffect)(() => {
		useDesk.persist.rehydrate();
		setMounted(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!mounted) return;
		const clock = setInterval(() => setNow(Date.now()), 250);
		const beat = setInterval(() => useDesk.getState().tick(), 1e3);
		return () => {
			clearInterval(clock);
			clearInterval(beat);
		};
	}, [mounted]);
	(0, import_react.useEffect)(() => {
		if (!mounted) return;
		const pair = pairById(pairId);
		let stop = false;
		let timer = 0;
		let delay = 2e3;
		async function pull() {
			const result = await getMarket({ data: { symbol: pair.yahoo } });
			if (stop) return;
			if (!result.ok) {
				if (useDesk.getState().pairId === pair.id) useDesk.setState({ error: result.error });
				delay = Math.min(delay * 2, 15e3);
			} else {
				delay = 2e3;
				if (useDesk.getState().pairId === pair.id) useDesk.getState().ingest(result);
			}
			timer = window.setTimeout(() => void pull(), delay);
		}
		pull();
		return () => {
			stop = true;
			window.clearTimeout(timer);
		};
	}, [mounted, pairId]);
	(0, import_react.useEffect)(() => {
		if (!mounted || !telegramOn) return;
		const token = telegramToken.trim();
		const chatId = telegramChatId.trim();
		if (!token || !chatId) return;
		for (const trade of trades) {
			if (!trade.notify) continue;
			if (!(trade.entryTime * 1e3 > Date.now() - 18e4)) continue;
			const wantSignal = trade.result === "pending" && !trade.signalSent;
			const wantResult = trade.result !== "pending" && !trade.resultSent;
			if (!wantSignal && !wantResult) continue;
			const key = `${wantSignal ? "s" : "r"}:${trade.id}`;
			if (inflight.current.has(key)) continue;
			if ((retryAt.current.get(key) ?? 0) > Date.now()) continue;
			inflight.current.add(key);
			const text = wantSignal ? signalText(trade) : resultText(trade);
			const kind = wantSignal ? "signal" : "result";
			sendTelegram({ data: {
				token,
				chatId,
				text
			} }).then((result) => {
				inflight.current.delete(key);
				if (result.ok) {
					markSent(trade.id, kind);
					patch({ telegramNote: kind === "signal" ? "সিগন্যাল টেলিগ্রামে গেছে" : "রেজাল্ট টেলিগ্রামে গেছে" });
				} else {
					retryAt.current.set(key, Date.now() + 2e4);
					patch({ telegramNote: result.error });
				}
			});
		}
	}, [
		mounted,
		telegramOn,
		telegramToken,
		telegramChatId,
		trades,
		markSent,
		patch
	]);
	const pair = pairById(pairId);
	const liveSnap = snap && snap.symbol === pair.yahoo ? snap : null;
	const nowMs = mounted ? now + skewMs : 0;
	const nowSec = nowMs > 0 ? Math.floor(nowMs / 1e3) : 0;
	const pending = trades.find((trade) => trade.result === "pending") ?? null;
	const stats = sessionStats(trades);
	const preview = liveSnap && nowSec ? readPreview(liveSnap, nowSec) : null;
	const stale = liveSnap && nowSec ? marketIsStale(liveSnap, nowSec) : false;
	const minuteStart = nowSec ? floorMinute(nowSec) : 0;
	const second = nowSec ? nowSec - minuteStart : 0;
	const inWindow = second <= 20;
	const entryAt = inWindow ? minuteStart : minuteStart + 60;
	const countdown = inWindow ? 20 - second : 60 - second;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen w-full max-w-6xl px-4 py-5 sm:px-6 sm:py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-faint uppercase",
					children: "Quotex · 1 min"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-5xl leading-none italic text-fg sm:text-6xl",
					children: "Ekmin"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-faint",
						children: "তোমার সময়"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-medium tabular-nums text-fg",
						children: mounted && now ? formatClock(now) : "—"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-2xl text-sm text-pretty text-muted",
				children: "এন্ট্রি টাইম, কনফিডেন্স আর কারণ দেয়। মিনিট শেষ হলে জিত নাকি হার সেটা ক্যান্ডেল দেখে অটো হিসাব করে। চাইলে টেলিগ্রামে পাঠায়। অর্ডার Quotex-এ নিজে দিতে হবে — এখান থেকে ট্রেড যায় না।"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex gap-2 overflow-x-auto pb-1",
				children: PAIRS.map((item) => {
					const on = item.id === pair.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setPair(item.id),
						className: cn("h-11 shrink-0 rounded-full border px-4 text-sm font-medium", on ? "border-accent bg-accent text-accent-fg" : "border-line bg-surface text-fg"),
						children: item.label
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid items-start gap-4 lg:grid-cols-[minmax(0,1.6fr)_minmax(17rem,0.9fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "rounded-3xl bg-surface p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignalBody, {
						pairLabel: pair.label,
						pairKind: pair.kind,
						pending,
						preview,
						snap: liveSnap,
						error,
						stale,
						mounted,
						inWindow,
						entryAt,
						countdown: Math.max(0, countdown),
						nowSec,
						minConfidence,
						auto,
						onTake: () => {
							const result = takeSignal();
							setTakeNote(result.ok ? "এই মিনিটের সিগন্যাল নেওয়া হয়েছে" : result.error);
						},
						takeNote
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-3xl bg-surface p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-sm font-medium text-muted",
										children: "সেশন"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-faint",
										children: [
											"স্টেক ",
											stake.toFixed(2),
											" · পেআউট ",
											payoutPct,
											"%"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-display text-5xl leading-none tabular-nums text-fg",
									children: stats.rate == null ? "—" : `${Math.round(stats.rate * 100)}%`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: "উইন রেট"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "mt-4 grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											label: "জিত",
											value: String(stats.wins),
											tone: "up"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											label: "হার",
											value: String(stats.losses),
											tone: "down"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											label: "নেট",
											value: formatPnl(stats.pnl),
											tone: stats.pnl > 0 ? "up" : stats.pnl < 0 ? "down" : "flat"
										})
									]
								}),
								stats.streak >= 2 && stats.streakKind ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 text-sm text-muted",
									children: [
										stats.streak,
										"টা টানা ",
										stats.streakKind === "win" ? "জিত" : "হার"
									]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-xs text-pretty text-faint",
									children: "হিসাব এই পেজের লাইভ ক্যান্ডেলের ওপেন বনাম ক্লোজ। Quotex OTC-র দাম আলাদা হতে পারে।"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-3xl bg-surface p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-sm font-medium text-muted",
									children: "অটো"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-fg",
										children: "কনফিডেন্স মিললে নিজে নেবে"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										role: "switch",
										"aria-checked": auto,
										"aria-label": "অটো সিগন্যাল",
										onClick: () => patch({ auto: !auto }),
										className: cn("flex h-11 w-16 items-center rounded-full border border-line px-1", auto ? "bg-accent" : "bg-subtle"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-8 rounded-full bg-bg transition-transform duration-150", auto ? "translate-x-6" : "translate-x-0") })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-4 block text-sm text-muted",
									htmlFor: "min-conf",
									children: [
										"মিনিমাম কনফিডেন্স ",
										minConfidence,
										"%"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "min-conf",
									type: "range",
									min: 50,
									max: 90,
									step: 1,
									value: minConfidence,
									onChange: (event) => patch({ minConfidence: Number(event.target.value) }),
									className: "mt-2 h-11 w-full accent-accent"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 grid grid-cols-2 gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-sm text-muted",
										htmlFor: "stake",
										children: ["স্টেক", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "stake",
											type: "number",
											min: .5,
											step: .5,
											value: stake,
											onChange: (event) => patch({ stake: Number(event.target.value) }),
											className: "mt-1 h-11 w-full rounded-lg border border-line bg-bg px-3 text-fg tabular-nums outline-none focus-visible:ring-2 focus-visible:ring-accent"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block text-sm text-muted",
										htmlFor: "payout",
										children: ["পেআউট %", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "payout",
											type: "number",
											min: 1,
											max: 100,
											step: 1,
											value: payoutPct,
											onChange: (event) => patch({ payoutPct: Number(event.target.value) }),
											className: "mt-1 h-11 w-full rounded-lg border border-line bg-bg px-3 text-fg tabular-nums outline-none focus-visible:ring-2 focus-visible:ring-accent"
										})]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-3xl bg-surface p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-sm font-medium text-muted",
										children: "টেলিগ্রাম"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										role: "switch",
										"aria-checked": telegramOn,
										"aria-label": "টেলিগ্রাম পাঠানো",
										onClick: () => patch({ telegramOn: !telegramOn }),
										className: cn("flex h-11 w-16 items-center rounded-full border border-line px-1", telegramOn ? "bg-accent" : "bg-subtle"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-8 rounded-full bg-bg transition-transform duration-150", telegramOn ? "translate-x-6" : "translate-x-0") })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
									className: "mt-3 list-decimal space-y-1 pl-4 text-sm text-pretty text-muted",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "BotFather-এ /newbot দিয়ে বট বানাও" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "টোকেন এখানে বসাও, বটকে একটা মেসেজ পাঠাও" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "চ্যাট আইডি নাও, তারপর পাঠানো চালু রাখো" })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-3 block text-sm text-muted",
									htmlFor: "tg-token",
									children: ["বট টোকেন", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "tg-token",
										type: "password",
										autoComplete: "off",
										value: telegramToken,
										onChange: (event) => patch({
											telegramToken: event.target.value,
											telegramNote: ""
										}),
										className: "mt-1 h-11 w-full rounded-lg border border-line bg-bg px-3 text-fg outline-none focus-visible:ring-2 focus-visible:ring-accent"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-3 block text-sm text-muted",
									htmlFor: "tg-chat",
									children: ["চ্যাট আইডি", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "tg-chat",
										inputMode: "numeric",
										value: telegramChatId,
										onChange: (event) => patch({
											telegramChatId: event.target.value,
											telegramNote: ""
										}),
										className: "mt-1 h-11 w-full rounded-lg border border-line bg-bg px-3 text-fg tabular-nums outline-none focus-visible:ring-2 focus-visible:ring-accent"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: telegramBusy !== null,
										onClick: () => {
											setTelegramBusy("find");
											findTelegramChat({ data: { token: telegramToken } }).then((result) => {
												if (result.ok && result.chatId) patch({
													telegramChatId: result.chatId,
													telegramNote: result.bot ? `@${result.bot} যুক্ত` : "চ্যাট আইডি পাওয়া গেছে"
												});
												else patch({ telegramNote: result.ok ? "চ্যাট আইডি পাওয়া যায়নি" : result.error });
											}).catch(() => patch({ telegramNote: "টোকেন চেক করো" })).finally(() => setTelegramBusy(null));
										},
										className: "h-11 rounded-lg border border-line bg-subtle text-sm font-medium text-fg disabled:opacity-40",
										children: telegramBusy === "find" ? "খুঁজছি" : "চ্যাট আইডি"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: telegramBusy !== null,
										onClick: () => {
											setTelegramBusy("test");
											sendTelegram({ data: {
												token: telegramToken,
												chatId: telegramChatId,
												text: "EKMIN টেস্ট। সিগন্যাল এখানে আসবে।"
											} }).then((result) => {
												patch({ telegramNote: result.ok ? "টেস্ট মেসেজ গেছে" : result.error });
											}).catch(() => patch({ telegramNote: "টেলিগ্রামে পৌঁছায়নি" })).finally(() => setTelegramBusy(null));
										},
										className: "h-11 rounded-lg bg-accent text-sm font-medium text-accent-fg disabled:opacity-40",
										children: telegramBusy === "test" ? "পাঠাচ্ছি" : "টেস্ট"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 min-h-5 text-sm text-pretty text-muted",
									children: telegramNote
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-pretty text-faint",
									children: "টোকেন শুধু এই ব্রাউজারে থাকে। পেজ খোলা থাকলেই মেসেজ যায়।"
								})
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-4 rounded-3xl bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium text-muted",
						children: "ইতিহাস"
					}), trades.length > 0 ? confirmClear ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => patch({ confirmClear: false }),
							className: "h-11 rounded-lg border border-line px-3 text-sm text-fg",
							children: "না"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: clearTrades,
							className: "h-11 rounded-lg bg-accent px-3 text-sm font-medium text-accent-fg",
							children: "মুছে দাও"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => patch({ confirmClear: true }),
						className: "h-11 rounded-lg border border-line px-3 text-sm text-muted",
						children: "ইতিহাস মুছো"
					}) : null]
				}), trades.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-pretty text-muted",
					children: "এখনো কোনো ট্রেড নাই। অটো চালু থাকলে এন্ট্রি উইন্ডোতে কনফিডেন্স মিললে সিগন্যাল নিজে ঢুকবে।"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-line",
					children: trades.slice(0, 24).map((trade) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryRow, { trade }, trade.id))
				})]
			})
		]
	});
}
function Stat({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-bg px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-faint",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: cn("mt-1 text-lg font-medium tabular-nums", tone === "up" && "text-up", tone === "down" && "text-down", tone === "flat" && "text-fg"),
			children: value
		})]
	});
}
function SignalBody({ pairLabel, pairKind, pending, preview, snap, error, stale, mounted, inWindow, entryAt, countdown, nowSec, minConfidence, auto, onTake, takeNote }) {
	const locked = pending;
	const direction = locked?.direction ?? preview?.direction ?? null;
	const confidence = locked?.confidence ?? preview?.confidence ?? null;
	const reason = locked?.reason ?? preview?.reason ?? null;
	const sample = snap?.price ?? locked?.entryPrice ?? 1;
	const willSkip = !locked && auto && inWindow && preview != null && (!preview.tradable || preview.confidence < minConfidence || stale);
	let status = "মার্কেট আনছি";
	if (!mounted) status = "মার্কেট আনছি";
	else if (error && !snap) status = error;
	else if (stale) status = "লাইভ ক্যান্ডেল নেই";
	else if (locked) status = "ট্রেড চলছে";
	else if (!inWindow) status = "পরের এন্ট্রি";
	else if (willSkip) status = "এই মিনিটে অটো স্কিপ";
	else if (inWindow) status = "এন্ট্রি উইন্ডো";
	const remain = locked ? Math.max(0, locked.entryTime + 60 - nowSec) : countdown;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [pairLabel, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-faint",
					children: [" · ", pairKind]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm font-medium text-fg",
				children: status
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-right text-sm tabular-nums text-muted",
				children: locked ? `বাকি ${remain}সে` : inWindow ? `উইন্ডো ${remain}সে` : `বাকি ${remain}সে`
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 flex items-end justify-between gap-4",
			"aria-live": "polite",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-faint uppercase",
				children: "দিক"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("font-display text-6xl leading-none italic sm:text-7xl", direction === "CALL" && "text-up", direction === "PUT" && "text-down", !direction && "text-faint"),
				children: direction ?? "—"
			})] }), direction === "CALL" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
				className: "mb-2 size-8 text-up",
				"aria-hidden": "true"
			}) : direction === "PUT" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownRight, {
				className: "mb-2 size-8 text-down",
				"aria-hidden": "true"
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid grid-cols-2 gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Entry time",
				value: entryAt ? formatHM(locked?.entryTime ?? entryAt) : "—"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Confidence",
				value: confidence == null ? "—" : `${confidence}%`,
				hint: locked ? "লক" : auto ? `অটো ${minConfidence}%+` : "ম্যানুয়াল"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 h-1.5 overflow-hidden rounded-full bg-bg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full rounded-full bg-accent",
				style: { width: `${confidence ?? 0}%` }
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-faint uppercase",
				children: "Reason"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-pretty text-fg",
				children: reason ?? (error && !snap ? error : "ক্যান্ডেল পড়ছি। একটু থাকো।")
			})]
		}),
		preview && !locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 grid gap-2 sm:grid-cols-2",
			children: preview.factors.map((factor) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-baseline justify-between gap-3 rounded-lg bg-bg px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-faint",
					children: factor.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-right text-sm text-fg",
					children: factor.note
				})]
			}, factor.label))
		}) : null,
		locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-4 text-sm tabular-nums text-muted",
			children: [
				"এন্ট্রি ",
				locked.entryPrice == null ? "—" : formatPrice(locked.entryPrice, sample),
				snap ? ` · এখন ${formatPrice(snap.price, sample)}` : ""
			]
		}) : snap ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-4 text-sm tabular-nums text-muted",
			children: ["এখন ", formatPrice(snap.price, sample)]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 h-36 overflow-hidden rounded-lg bg-bg",
			children: mounted && snap ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceChart, { candles: snap.candles }) : null
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex flex-col gap-2 sm:flex-row sm:items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onTake,
				disabled: Boolean(locked) || !preview || !inWindow || stale,
				className: "h-11 rounded-lg bg-accent px-4 text-sm font-medium text-accent-fg disabled:opacity-40",
				children: locked ? "ট্রেড চলছে" : "এই সিগন্যাল নাও"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-pretty text-muted",
				children: takeNote
			})]
		})
	] });
}
function Field({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-bg px-3 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-faint",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-2xl font-medium tabular-nums text-fg",
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: hint
			}) : null
		]
	});
}
function PriceChart({ candles }) {
	const data = candles.slice(-48).map((candle) => ({
		t: candle.time,
		c: candle.close
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
		width: "100%",
		height: "100%",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AreaChart, {
			data,
			margin: {
				top: 12,
				right: 0,
				left: 0,
				bottom: 0
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
				type: "monotone",
				dataKey: "c",
				stroke: "var(--color-accent)",
				fill: "var(--color-subtle)",
				strokeWidth: 1.5,
				dot: false,
				isAnimationActive: false
			})
		})
	});
}
function HistoryRow({ trade }) {
	const sample = trade.entryPrice ?? trade.exitPrice ?? 1;
	const word = trade.result === "win" ? "জিত" : trade.result === "loss" ? "হার" : trade.result === "draw" ? "ড্র" : "চলছে";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-center justify-between gap-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-medium text-fg",
				children: [
					trade.label,
					" · ",
					trade.direction
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "truncate text-xs text-muted",
				children: [
					formatHM(trade.entryTime),
					" · ",
					trade.confidence,
					"%",
					trade.entryPrice != null && trade.exitPrice != null ? ` · ${formatPrice(trade.entryPrice, sample)} → ${formatPrice(trade.exitPrice, sample)}` : ""
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-right",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("text-sm font-medium", trade.result === "win" && "text-up", trade.result === "loss" && "text-down", trade.result !== "win" && trade.result !== "loss" && "text-muted"),
				children: word
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tabular-nums text-faint",
				children: trade.pnl == null ? "—" : formatPnl(trade.pnl)
			})]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Desk, {});
}
//#endregion
export { Home as component };
