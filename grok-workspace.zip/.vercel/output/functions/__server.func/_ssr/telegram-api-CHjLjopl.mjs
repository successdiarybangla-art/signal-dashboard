import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/telegram-api-CHjLjopl.js
function cleanToken(token) {
	const value = token.trim();
	if (!/^\d{6,12}:[A-Za-z0-9_-]{20,}$/.test(value)) return null;
	return value;
}
function cleanChat(chatId) {
	const value = chatId.trim();
	if (!/^-?\d{1,20}$/.test(value)) return null;
	return value;
}
async function telegram(token, method, body) {
	return await (await fetch(`https://api.telegram.org/bot${token}/${method}`, {
		method: body ? "POST" : "GET",
		headers: body ? { "content-type": "application/json" } : void 0,
		body: body ? JSON.stringify(body) : void 0,
		signal: AbortSignal.timeout(12e3)
	})).json();
}
var sendTelegram_createServerFn_handler = createServerRpc({
	id: "7e1aff2ed5e393c371117bf79fa51ea3acee101efd5245e9b347c8e7c8d6803d",
	name: "sendTelegram",
	filename: "src/lib/telegram-api.ts"
}, (opts) => sendTelegram.__executeServer(opts));
var sendTelegram = createServerFn({ method: "POST" }).validator((input) => {
	const token = cleanToken(input?.token ?? "");
	const chatId = cleanChat(input?.chatId ?? "");
	const text = (input?.text ?? "").slice(0, 3500);
	if (!token) throw new Error("টোকেন ঠিক না");
	if (!chatId) throw new Error("চ্যাট আইডি ঠিক না");
	if (!text) throw new Error("খালি মেসেজ");
	return {
		token,
		chatId,
		text
	};
}).handler(sendTelegram_createServerFn_handler, async ({ data }) => {
	try {
		const json = await telegram(data.token, "sendMessage", {
			chat_id: data.chatId,
			text: data.text
		});
		if (!json.ok) return {
			ok: false,
			error: json.description || "টেলিগ্রাম পাঠায়নি"
		};
		return { ok: true };
	} catch {
		return {
			ok: false,
			error: "টেলিগ্রামে পৌঁছায়নি"
		};
	}
});
var findTelegramChat_createServerFn_handler = createServerRpc({
	id: "33fec8b1e112bd9cf682c6102569cb09c65ca659f7d7113353136bff6b5f5581",
	name: "findTelegramChat",
	filename: "src/lib/telegram-api.ts"
}, (opts) => findTelegramChat.__executeServer(opts));
var findTelegramChat = createServerFn({ method: "POST" }).validator((input) => {
	const token = cleanToken(input?.token ?? "");
	if (!token) throw new Error("টোকেন ঠিক না");
	return { token };
}).handler(findTelegramChat_createServerFn_handler, async ({ data }) => {
	try {
		const me = await telegram(data.token, "getMe");
		if (!me.ok) return {
			ok: false,
			error: "টোকেন মানা হয়নি। BotFather থেকে নতুন করে নাও।"
		};
		const bot = me.result && typeof me.result === "object" && "username" in me.result ? String(me.result.username ?? "") : "";
		const updates = await telegram(data.token, "getUpdates");
		const list = Array.isArray(updates.result) ? updates.result : [];
		let chatId = "";
		for (let i = list.length - 1; i >= 0; i--) {
			const item = list[i];
			const id = item.message?.chat?.id ?? item.edited_message?.chat?.id;
			if (typeof id === "number") {
				chatId = String(id);
				break;
			}
		}
		if (!chatId) return {
			ok: false,
			error: bot ? `@${bot} কে একটা মেসেজ পাঠাও, তারপর আবার চাপো।` : "বটকে আগে একটা মেসেজ পাঠাও।"
		};
		return {
			ok: true,
			chatId,
			bot
		};
	} catch {
		return {
			ok: false,
			error: "টেলিগ্রামে পৌঁছায়নি"
		};
	}
});
//#endregion
export { findTelegramChat_createServerFn_handler, sendTelegram_createServerFn_handler };
