//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CqCQvTYf.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DsRz1m77.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DsRz1m77.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DAP1zetw.js"]
	}
} });
//#endregion
export { tsrStartManifest };
