import { useEffect, useRef, useState } from "react";
import { Area, AreaChart, ResponsiveContainer } from "recharts";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import { getMarket } from "@/lib/market-api";
import { findTelegramChat, sendTelegram } from "@/lib/telegram-api";
import { PAIRS, pairById } from "@/lib/pairs";
import { cn } from "@/lib/cn";
import {
  ENTRY_WINDOW,
  floorMinute,
  formatClock,
  formatHM,
  formatPnl,
  formatPrice,
  resultText,
  sessionStats,
  signalText,
  type Trade,
} from "@/lib/candles";
import { marketIsStale, readPreview, useDesk, type Snap } from "@/lib/store";

export function Desk() {
  const pairId = useDesk((state) => state.pairId);
  const auto = useDesk((state) => state.auto);
  const minConfidence = useDesk((state) => state.minConfidence);
  const stake = useDesk((state) => state.stake);
  const payoutPct = useDesk((state) => state.payoutPct);
  const telegramToken = useDesk((state) => state.telegramToken);
  const telegramChatId = useDesk((state) => state.telegramChatId);
  const telegramOn = useDesk((state) => state.telegramOn);
  const trades = useDesk((state) => state.trades);
  const snap = useDesk((state) => state.snap);
  const error = useDesk((state) => state.error);
  const skewMs = useDesk((state) => state.skewMs);
  const telegramNote = useDesk((state) => state.telegramNote);
  const confirmClear = useDesk((state) => state.confirmClear);
  const setPair = useDesk((state) => state.setPair);
  const patch = useDesk((state) => state.patch);
  const takeSignal = useDesk((state) => state.takeSignal);
  const markSent = useDesk((state) => state.markSent);
  const clearTrades = useDesk((state) => state.clearTrades);

  const [mounted, setMounted] = useState(false);
  const [now, setNow] = useState(0);
  const [takeNote, setTakeNote] = useState("");
  const [telegramBusy, setTelegramBusy] = useState<"find" | "test" | null>(null);
  const inflight = useRef(new Set<string>());
  const retryAt = useRef(new Map<string, number>());

  useEffect(() => {
    void useDesk.persist.rehydrate();
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!mounted) return;
    const clock = setInterval(() => setNow(Date.now()), 250);
    const beat = setInterval(() => useDesk.getState().tick(), 1000);
    return () => {
      clearInterval(clock);
      clearInterval(beat);
    };
  }, [mounted]);

  useEffect(() => {
    if (!mounted) return;
    const pair = pairById(pairId);
    let stop = false;
    let timer = 0;
    let delay = 2000;

    async function pull() {
      const result = await getMarket({ data: { symbol: pair.yahoo } });
      if (stop) return;
      if (!result.ok) {
        if (useDesk.getState().pairId === pair.id) {
          useDesk.setState({ error: result.error });
        }
        delay = Math.min(delay * 2, 15000);
      } else {
        delay = 2000;
        if (useDesk.getState().pairId === pair.id) {
          useDesk.getState().ingest(result);
        }
      }
      timer = window.setTimeout(() => void pull(), delay);
    }

    void pull();
    return () => {
      stop = true;
      window.clearTimeout(timer);
    };
  }, [mounted, pairId]);

  useEffect(() => {
    if (!mounted || !telegramOn) return;
    const token = telegramToken.trim();
    const chatId = telegramChatId.trim();
    if (!token || !chatId) return;

    for (const trade of trades) {
      if (!trade.notify) continue;
      const fresh = trade.entryTime * 1000 > Date.now() - 3 * 60 * 1000;
      if (!fresh) continue;
      const wantSignal = trade.result === "pending" && !trade.signalSent;
      const wantResult = trade.result !== "pending" && !trade.resultSent;
      if (!wantSignal && !wantResult) continue;
      const key = `${wantSignal ? "s" : "r"}:${trade.id}`;
      if (inflight.current.has(key)) continue;
      if ((retryAt.current.get(key) ?? 0) > Date.now()) continue;
      inflight.current.add(key);
      const text = wantSignal ? signalText(trade) : resultText(trade);
      const kind = wantSignal ? "signal" : "result";
      void sendTelegram({ data: { token, chatId, text } }).then((result) => {
        inflight.current.delete(key);
        if (result.ok) {
          markSent(trade.id, kind);
          patch({ telegramNote: kind === "signal" ? "সিগন্যাল টেলিগ্রামে গেছে" : "রেজাল্ট টেলিগ্রামে গেছে" });
        } else {
          retryAt.current.set(key, Date.now() + 20000);
          patch({ telegramNote: result.error });
        }
      });
    }
  }, [mounted, telegramOn, telegramToken, telegramChatId, trades, markSent, patch]);

  const pair = pairById(pairId);
  const liveSnap = snap && snap.symbol === pair.yahoo ? snap : null;
  const nowMs = mounted ? now + skewMs : 0;
  const nowSec = nowMs > 0 ? Math.floor(nowMs / 1000) : 0;
  const pending = trades.find((trade) => trade.result === "pending") ?? null;
  const stats = sessionStats(trades);
  const preview = liveSnap && nowSec ? readPreview(liveSnap, nowSec) : null;
  const stale = liveSnap && nowSec ? marketIsStale(liveSnap, nowSec) : false;
  const minuteStart = nowSec ? floorMinute(nowSec) : 0;
  const second = nowSec ? nowSec - minuteStart : 0;
  const inWindow = second <= ENTRY_WINDOW;
  const entryAt = inWindow ? minuteStart : minuteStart + 60;
  const countdown = inWindow ? ENTRY_WINDOW - second : 60 - second;

  return (
    <main className="mx-auto min-h-screen w-full max-w-6xl px-4 py-5 sm:px-6 sm:py-8">
      <header className="flex items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium tracking-widest text-faint uppercase">Quotex · 1 min</p>
          <h1 className="font-display text-5xl leading-none italic text-fg sm:text-6xl">Ekmin</h1>
        </div>
        <div className="text-right">
          <p className="text-xs text-faint">তোমার সময়</p>
          <p className="text-lg font-medium tabular-nums text-fg">{mounted && now ? formatClock(now) : "—"}</p>
        </div>
      </header>

      <p className="mt-4 max-w-2xl text-sm text-pretty text-muted">
        এন্ট্রি টাইম, কনফিডেন্স আর কারণ দেয়। মিনিট শেষ হলে জিত নাকি হার সেটা ক্যান্ডেল দেখে অটো হিসাব করে।
        চাইলে টেলিগ্রামে পাঠায়। অর্ডার Quotex-এ নিজে দিতে হবে — এখান থেকে ট্রেড যায় না।
      </p>

      <div className="mt-5 flex gap-2 overflow-x-auto pb-1">
        {PAIRS.map((item) => {
          const on = item.id === pair.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setPair(item.id)}
              className={cn(
                "h-11 shrink-0 rounded-full border px-4 text-sm font-medium",
                on
                  ? "border-accent bg-accent text-accent-fg"
                  : "border-line bg-surface text-fg",
              )}
            >
              {item.label}
            </button>
          );
        })}
      </div>

      <div className="mt-4 grid items-start gap-4 lg:grid-cols-[minmax(0,1.6fr)_minmax(17rem,0.9fr)]">
        <section className="rounded-3xl bg-surface p-4">
          <SignalBody
            pairLabel={pair.label}
            pairKind={pair.kind}
            pending={pending}
            preview={preview}
            snap={liveSnap}
            error={error}
            stale={stale}
            mounted={mounted}
            inWindow={inWindow}
            entryAt={entryAt}
            countdown={Math.max(0, countdown)}
            nowSec={nowSec}
            minConfidence={minConfidence}
            auto={auto}
            onTake={() => {
              const result = takeSignal();
              setTakeNote(result.ok ? "এই মিনিটের সিগন্যাল নেওয়া হয়েছে" : result.error);
            }}
            takeNote={takeNote}
          />
        </section>

        <div className="grid gap-4">
          <section className="rounded-3xl bg-surface p-4">
            <div className="flex items-baseline justify-between gap-3">
              <h2 className="text-sm font-medium text-muted">সেশন</h2>
              <p className="text-xs text-faint">স্টেক {stake.toFixed(2)} · পেআউট {payoutPct}%</p>
            </div>
            <p className="mt-3 font-display text-5xl leading-none tabular-nums text-fg">
              {stats.rate == null ? "—" : `${Math.round(stats.rate * 100)}%`}
            </p>
            <p className="mt-1 text-sm text-muted">উইন রেট</p>
            <dl className="mt-4 grid grid-cols-3 gap-2">
              <Stat label="জিত" value={String(stats.wins)} tone="up" />
              <Stat label="হার" value={String(stats.losses)} tone="down" />
              <Stat label="নেট" value={formatPnl(stats.pnl)} tone={stats.pnl > 0 ? "up" : stats.pnl < 0 ? "down" : "flat"} />
            </dl>
            {stats.streak >= 2 && stats.streakKind ? (
              <p className="mt-3 text-sm text-muted">
                {stats.streak}টা টানা {stats.streakKind === "win" ? "জিত" : "হার"}
              </p>
            ) : null}
            <p className="mt-3 text-xs text-pretty text-faint">
              হিসাব এই পেজের লাইভ ক্যান্ডেলের ওপেন বনাম ক্লোজ। Quotex OTC-র দাম আলাদা হতে পারে।
            </p>
          </section>

          <section className="rounded-3xl bg-surface p-4">
            <h2 className="text-sm font-medium text-muted">অটো</h2>
            <div className="mt-3 flex items-center justify-between gap-3">
              <p className="text-sm text-fg">কনফিডেন্স মিললে নিজে নেবে</p>
              <button
                type="button"
                role="switch"
                aria-checked={auto}
                aria-label="অটো সিগন্যাল"
                onClick={() => patch({ auto: !auto })}
                className={cn(
                  "flex h-11 w-16 items-center rounded-full border border-line px-1",
                  auto ? "bg-accent" : "bg-subtle",
                )}
              >
                <span
                  className={cn(
                    "size-8 rounded-full bg-bg transition-transform duration-150",
                    auto ? "translate-x-6" : "translate-x-0",
                  )}
                />
              </button>
            </div>
            <label className="mt-4 block text-sm text-muted" htmlFor="min-conf">
              মিনিমাম কনফিডেন্স {minConfidence}%
            </label>
            <input
              id="min-conf"
              type="range"
              min={50}
              max={90}
              step={1}
              value={minConfidence}
              onChange={(event) => patch({ minConfidence: Number(event.target.value) })}
              className="mt-2 h-11 w-full accent-accent"
            />
            <div className="mt-3 grid grid-cols-2 gap-3">
              <label className="block text-sm text-muted" htmlFor="stake">
                স্টেক
                <input
                  id="stake"
                  type="number"
                  min={0.5}
                  step={0.5}
                  value={stake}
                  onChange={(event) => patch({ stake: Number(event.target.value) })}
                  className="mt-1 h-11 w-full rounded-lg border border-line bg-bg px-3 text-fg tabular-nums outline-none focus-visible:ring-2 focus-visible:ring-accent"
                />
              </label>
              <label className="block text-sm text-muted" htmlFor="payout">
                পেআউট %
                <input
                  id="payout"
                  type="number"
                  min={1}
                  max={100}
                  step={1}
                  value={payoutPct}
                  onChange={(event) => patch({ payoutPct: Number(event.target.value) })}
                  className="mt-1 h-11 w-full rounded-lg border border-line bg-bg px-3 text-fg tabular-nums outline-none focus-visible:ring-2 focus-visible:ring-accent"
                />
              </label>
            </div>
          </section>

          <section className="rounded-3xl bg-surface p-4">
            <div className="flex items-baseline justify-between gap-3">
              <h2 className="text-sm font-medium text-muted">টেলিগ্রাম</h2>
              <button
                type="button"
                role="switch"
                aria-checked={telegramOn}
                aria-label="টেলিগ্রাম পাঠানো"
                onClick={() => patch({ telegramOn: !telegramOn })}
                className={cn(
                  "flex h-11 w-16 items-center rounded-full border border-line px-1",
                  telegramOn ? "bg-accent" : "bg-subtle",
                )}
              >
                <span
                  className={cn(
                    "size-8 rounded-full bg-bg transition-transform duration-150",
                    telegramOn ? "translate-x-6" : "translate-x-0",
                  )}
                />
              </button>
            </div>
            <ol className="mt-3 list-decimal space-y-1 pl-4 text-sm text-pretty text-muted">
              <li>BotFather-এ /newbot দিয়ে বট বানাও</li>
              <li>টোকেন এখানে বসাও, বটকে একটা মেসেজ পাঠাও</li>
              <li>চ্যাট আইডি নাও, তারপর পাঠানো চালু রাখো</li>
            </ol>
            <label className="mt-3 block text-sm text-muted" htmlFor="tg-token">
              বট টোকেন
              <input
                id="tg-token"
                type="password"
                autoComplete="off"
                value={telegramToken}
                onChange={(event) => patch({ telegramToken: event.target.value, telegramNote: "" })}
                className="mt-1 h-11 w-full rounded-lg border border-line bg-bg px-3 text-fg outline-none focus-visible:ring-2 focus-visible:ring-accent"
              />
            </label>
            <label className="mt-3 block text-sm text-muted" htmlFor="tg-chat">
              চ্যাট আইডি
              <input
                id="tg-chat"
                inputMode="numeric"
                value={telegramChatId}
                onChange={(event) => patch({ telegramChatId: event.target.value, telegramNote: "" })}
                className="mt-1 h-11 w-full rounded-lg border border-line bg-bg px-3 text-fg tabular-nums outline-none focus-visible:ring-2 focus-visible:ring-accent"
              />
            </label>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button
                type="button"
                disabled={telegramBusy !== null}
                onClick={() => {
                  setTelegramBusy("find");
                  void findTelegramChat({ data: { token: telegramToken } })
                    .then((result) => {
                      if (result.ok && result.chatId) {
                        patch({
                          telegramChatId: result.chatId,
                          telegramNote: result.bot ? `@${result.bot} যুক্ত` : "চ্যাট আইডি পাওয়া গেছে",
                        });
                      } else {
                        patch({ telegramNote: result.ok ? "চ্যাট আইডি পাওয়া যায়নি" : result.error });
                      }
                    })
                    .catch(() => patch({ telegramNote: "টোকেন চেক করো" }))
                    .finally(() => setTelegramBusy(null));
                }}
                className="h-11 rounded-lg border border-line bg-subtle text-sm font-medium text-fg disabled:opacity-40"
              >
                {telegramBusy === "find" ? "খুঁজছি" : "চ্যাট আইডি"}
              </button>
              <button
                type="button"
                disabled={telegramBusy !== null}
                onClick={() => {
                  setTelegramBusy("test");
                  void sendTelegram({
                    data: {
                      token: telegramToken,
                      chatId: telegramChatId,
                      text: "EKMIN টেস্ট। সিগন্যাল এখানে আসবে।",
                    },
                  })
                    .then((result) => {
                      patch({ telegramNote: result.ok ? "টেস্ট মেসেজ গেছে" : result.error });
                    })
                    .catch(() => patch({ telegramNote: "টেলিগ্রামে পৌঁছায়নি" }))
                    .finally(() => setTelegramBusy(null));
                }}
                className="h-11 rounded-lg bg-accent text-sm font-medium text-accent-fg disabled:opacity-40"
              >
                {telegramBusy === "test" ? "পাঠাচ্ছি" : "টেস্ট"}
              </button>
            </div>
            <p className="mt-3 min-h-5 text-sm text-pretty text-muted">{telegramNote}</p>
            <p className="text-xs text-pretty text-faint">টোকেন শুধু এই ব্রাউজারে থাকে। পেজ খোলা থাকলেই মেসেজ যায়।</p>
          </section>
        </div>
      </div>

      <section className="mt-4 rounded-3xl bg-surface p-4">
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-sm font-medium text-muted">ইতিহাস</h2>
          {trades.length > 0 ? (
            confirmClear ? (
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => patch({ confirmClear: false })}
                  className="h-11 rounded-lg border border-line px-3 text-sm text-fg"
                >
                  না
                </button>
                <button
                  type="button"
                  onClick={clearTrades}
                  className="h-11 rounded-lg bg-accent px-3 text-sm font-medium text-accent-fg"
                >
                  মুছে দাও
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => patch({ confirmClear: true })}
                className="h-11 rounded-lg border border-line px-3 text-sm text-muted"
              >
                ইতিহাস মুছো
              </button>
            )
          ) : null}
        </div>
        {trades.length === 0 ? (
          <p className="mt-4 text-sm text-pretty text-muted">
            এখনো কোনো ট্রেড নাই। অটো চালু থাকলে এন্ট্রি উইন্ডোতে কনফিডেন্স মিললে সিগন্যাল নিজে ঢুকবে।
          </p>
        ) : (
          <ul className="mt-3 divide-y divide-line">
            {trades.slice(0, 24).map((trade) => (
              <HistoryRow key={trade.id} trade={trade} />
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone: "up" | "down" | "flat" }) {
  return (
    <div className="rounded-lg bg-bg px-3 py-2">
      <dt className="text-xs text-faint">{label}</dt>
      <dd
        className={cn(
          "mt-1 text-lg font-medium tabular-nums",
          tone === "up" && "text-up",
          tone === "down" && "text-down",
          tone === "flat" && "text-fg",
        )}
      >
        {value}
      </dd>
    </div>
  );
}

function SignalBody({
  pairLabel,
  pairKind,
  pending,
  preview,
  snap,
  error,
  stale,
  mounted,
  inWindow,
  entryAt,
  countdown,
  nowSec,
  minConfidence,
  auto,
  onTake,
  takeNote,
}: {
  pairLabel: string;
  pairKind: string;
  pending: Trade | null;
  preview: ReturnType<typeof readPreview>;
  snap: Snap | null;
  error: string | null;
  stale: boolean;
  mounted: boolean;
  inWindow: boolean;
  entryAt: number;
  countdown: number;
  nowSec: number;
  minConfidence: number;
  auto: boolean;
  onTake: () => void;
  takeNote: string;
}) {
  const locked = pending;
  const direction = locked?.direction ?? preview?.direction ?? null;
  const confidence = locked?.confidence ?? preview?.confidence ?? null;
  const reason = locked?.reason ?? preview?.reason ?? null;
  const sample = snap?.price ?? locked?.entryPrice ?? 1;
  const willSkip =
    !locked &&
    auto &&
    inWindow &&
    preview != null &&
    (!preview.tradable || preview.confidence < minConfidence || stale);

  let status = "মার্কেট আনছি";
  if (!mounted) status = "মার্কেট আনছি";
  else if (error && !snap) status = error;
  else if (stale) status = "লাইভ ক্যান্ডেল নেই";
  else if (locked) status = "ট্রেড চলছে";
  else if (!inWindow) status = "পরের এন্ট্রি";
  else if (willSkip) status = "এই মিনিটে অটো স্কিপ";
  else if (inWindow) status = "এন্ট্রি উইন্ডো";

  const remain = locked ? Math.max(0, locked.entryTime + 60 - nowSec) : countdown;

  return (
    <div>
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-sm text-muted">
            {pairLabel}
            <span className="text-faint"> · {pairKind}</span>
          </p>
          <p className="mt-1 text-sm font-medium text-fg">{status}</p>
        </div>
        <p className="text-right text-sm tabular-nums text-muted">
          {locked ? `বাকি ${remain}সে` : inWindow ? `উইন্ডো ${remain}সে` : `বাকি ${remain}সে`}
        </p>
      </div>

      <div className="mt-6 flex items-end justify-between gap-4" aria-live="polite">
        <div>
          <p className="text-xs tracking-widest text-faint uppercase">দিক</p>
          <p
            className={cn(
              "font-display text-6xl leading-none italic sm:text-7xl",
              direction === "CALL" && "text-up",
              direction === "PUT" && "text-down",
              !direction && "text-faint",
            )}
          >
            {direction ?? "—"}
          </p>
        </div>
        {direction === "CALL" ? (
          <ArrowUpRight className="mb-2 size-8 text-up" aria-hidden="true" />
        ) : direction === "PUT" ? (
          <ArrowDownRight className="mb-2 size-8 text-down" aria-hidden="true" />
        ) : null}
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3">
        <Field label="Entry time" value={entryAt ? formatHM(locked?.entryTime ?? entryAt) : "—"} />
        <Field
          label="Confidence"
          value={confidence == null ? "—" : `${confidence}%`}
          hint={locked ? "লক" : auto ? `অটো ${minConfidence}%+` : "ম্যানুয়াল"}
        />
      </div>

      <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-bg">
        <div
          className="h-full rounded-full bg-accent"
          style={{ width: `${confidence ?? 0}%` }}
        />
      </div>

      <div className="mt-4">
        <p className="text-xs tracking-widest text-faint uppercase">Reason</p>
        <p className="mt-1 text-sm text-pretty text-fg">
          {reason ?? (error && !snap ? error : "ক্যান্ডেল পড়ছি। একটু থাকো।")}
        </p>
      </div>

      {preview && !locked ? (
        <ul className="mt-4 grid gap-2 sm:grid-cols-2">
          {preview.factors.map((factor) => (
            <li key={factor.label} className="flex items-baseline justify-between gap-3 rounded-lg bg-bg px-3 py-2">
              <span className="text-xs text-faint">{factor.label}</span>
              <span className="text-right text-sm text-fg">{factor.note}</span>
            </li>
          ))}
        </ul>
      ) : null}

      {locked ? (
        <p className="mt-4 text-sm tabular-nums text-muted">
          এন্ট্রি {locked.entryPrice == null ? "—" : formatPrice(locked.entryPrice, sample)}
          {snap ? ` · এখন ${formatPrice(snap.price, sample)}` : ""}
        </p>
      ) : snap ? (
        <p className="mt-4 text-sm tabular-nums text-muted">এখন {formatPrice(snap.price, sample)}</p>
      ) : null}

      <div className="mt-4 h-36 overflow-hidden rounded-lg bg-bg">
        {mounted && snap ? <PriceChart candles={snap.candles} /> : null}
      </div>

      <div className="mt-4 flex flex-col gap-2 sm:flex-row sm:items-center">
        <button
          type="button"
          onClick={onTake}
          disabled={Boolean(locked) || !preview || !inWindow || stale}
          className="h-11 rounded-lg bg-accent px-4 text-sm font-medium text-accent-fg disabled:opacity-40"
        >
          {locked ? "ট্রেড চলছে" : "এই সিগন্যাল নাও"}
        </button>
        <p className="text-sm text-pretty text-muted">{takeNote}</p>
      </div>
    </div>
  );
}

function Field({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-lg bg-bg px-3 py-3">
      <p className="text-xs text-faint">{label}</p>
      <p className="mt-1 text-2xl font-medium tabular-nums text-fg">{value}</p>
      {hint ? <p className="text-xs text-muted">{hint}</p> : null}
    </div>
  );
}

function PriceChart({ candles }: { candles: Snap["candles"] }) {
  const data = candles.slice(-48).map((candle) => ({
    t: candle.time,
    c: candle.close,
  }));
  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={data} margin={{ top: 12, right: 0, left: 0, bottom: 0 }}>
        <Area
          type="monotone"
          dataKey="c"
          stroke="var(--color-accent)"
          fill="var(--color-subtle)"
          strokeWidth={1.5}
          dot={false}
          isAnimationActive={false}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

function HistoryRow({ trade }: { trade: Trade }) {
  const sample = trade.entryPrice ?? trade.exitPrice ?? 1;
  const word =
    trade.result === "win" ? "জিত" : trade.result === "loss" ? "হার" : trade.result === "draw" ? "ড্র" : "চলছে";
  return (
    <li className="flex items-center justify-between gap-3 py-3">
      <div className="min-w-0">
        <p className="text-sm font-medium text-fg">
          {trade.label} · {trade.direction}
        </p>
        <p className="truncate text-xs text-muted">
          {formatHM(trade.entryTime)} · {trade.confidence}%
          {trade.entryPrice != null && trade.exitPrice != null
            ? ` · ${formatPrice(trade.entryPrice, sample)} → ${formatPrice(trade.exitPrice, sample)}`
            : ""}
        </p>
      </div>
      <div className="text-right">
        <p
          className={cn(
            "text-sm font-medium",
            trade.result === "win" && "text-up",
            trade.result === "loss" && "text-down",
            trade.result !== "win" && trade.result !== "loss" && "text-muted",
          )}
        >
          {word}
        </p>
        <p className="text-xs tabular-nums text-faint">{trade.pnl == null ? "—" : formatPnl(trade.pnl)}</p>
      </div>
    </li>
  );
}
