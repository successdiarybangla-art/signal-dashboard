export type Candle = {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
};

export type Direction = "CALL" | "PUT";

export type Factor = {
  label: string;
  note: string;
  vote: number;
};

export type Analysis = {
  direction: Direction;
  confidence: number;
  tradable: boolean;
  reason: string;
  factors: Factor[];
};

export type TradeResult = "pending" | "win" | "loss" | "draw";

export type Trade = {
  id: string;
  pairId: string;
  label: string;
  direction: Direction;
  confidence: number;
  reason: string;
  entryTime: number;
  entryPrice: number | null;
  exitPrice: number | null;
  result: TradeResult;
  stake: number;
  payoutPct: number;
  pnl: number | null;
  notify: boolean;
  signalSent: boolean;
  resultSent: boolean;
};

export const ENTRY_WINDOW = 20;

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

export function ema(values: number[], period: number): number[] {
  const k = 2 / (period + 1);
  const out: number[] = [];
  let prev = 0;
  let seed = 0;
  for (let i = 0; i < period && i < values.length; i++) seed += values[i];
  seed /= Math.min(period, values.length);
  for (let i = 0; i < values.length; i++) {
    if (i < period - 1) {
      out.push(Number.NaN);
      continue;
    }
    if (i === period - 1) {
      prev = seed;
      out.push(prev);
      continue;
    }
    prev = values[i] * k + prev * (1 - k);
    out.push(prev);
  }
  return out;
}

export function rsi(closes: number[], period = 14): number | null {
  if (closes.length < period + 1) return null;
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const delta = closes[i] - closes[i - 1];
    if (delta >= 0) gain += delta;
    else loss -= delta;
  }
  let avgGain = gain / period;
  let avgLoss = loss / period;
  for (let i = period + 1; i < closes.length; i++) {
    const delta = closes[i] - closes[i - 1];
    const up = delta > 0 ? delta : 0;
    const down = delta < 0 ? -delta : 0;
    avgGain = (avgGain * (period - 1) + up) / period;
    avgLoss = (avgLoss * (period - 1) + down) / period;
  }
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

export function analyze(closed: Candle[]): Analysis | null {
  if (closed.length < 30) return null;
  const closes = closed.map((candle) => candle.close);
  const last = closes.length - 1;
  const price = closes[last];
  if (!Number.isFinite(price) || price === 0) return null;

  const ema9 = ema(closes, 9);
  const ema21 = ema(closes, 21);
  const fast = ema9[last];
  const slow = ema21[last];
  const fastPrev = ema9[last - 3];
  if (![fast, slow, fastPrev].every(Number.isFinite)) return null;

  const gapVote = clamp((fast - slow) / price / 0.0004, -1, 1);
  const slopeVote = clamp((fast - fastPrev) / price / 0.00015, -1, 1);

  const rsiValue = rsi(closes, 14) ?? 50;
  let rsiVote = clamp((rsiValue - 50) / 25, -1, 1);
  if (rsiValue >= 78) rsiVote = -0.35;
  if (rsiValue <= 22) rsiVote = 0.35;

  let impulse = 0;
  for (let i = 0; i < 4; i++) {
    const candle = closed[last - i];
    impulse += (candle.close - candle.open) / price;
  }
  const impulseVote = clamp(impulse / 0.0005, -1, 1);
  const structVote = clamp((price - closes[last - 8]) / price / 0.0008, -1, 1);

  const factors: Factor[] = [
    {
      label: "EMA",
      vote: gapVote,
      note:
        Math.abs(gapVote) < 0.08
          ? "EMA9 আর EMA21 প্রায় একসাথে"
          : gapVote > 0
            ? "EMA9, EMA21-এর উপরে"
            : "EMA9, EMA21-এর নিচে",
    },
    {
      label: "ঢাল",
      vote: slopeVote,
      note:
        Math.abs(slopeVote) < 0.08
          ? "EMA9 প্রায় সমান"
          : slopeVote > 0
            ? "EMA9 উপরে উঠছে"
            : "EMA9 নিচে নামছে",
    },
    {
      label: "RSI",
      vote: rsiVote,
      note:
        rsiValue >= 78
          ? `RSI ${Math.round(rsiValue)}, অতিরিক্ত কেনা`
          : rsiValue <= 22
            ? `RSI ${Math.round(rsiValue)}, অতিরিক্ত বিক্রি`
            : rsiVote >= 0
              ? `RSI ${Math.round(rsiValue)}, বায়ার দিক`
              : `RSI ${Math.round(rsiValue)}, সেলার দিক`,
    },
    {
      label: "বডি",
      vote: impulseVote,
      note:
        Math.abs(impulseVote) < 0.08
          ? "শেষ ক্যান্ডেলের বডি মিশ্র"
          : impulseVote > 0
            ? "শেষ ক্যান্ডেলগুলোর বডি উপরে"
            : "শেষ ক্যান্ডেলগুলোর বডি নিচে",
    },
    {
      label: "কাঠামো",
      vote: structVote,
      note:
        Math.abs(structVote) < 0.08
          ? "কয়েক মিনিটে দাম প্রায় একই"
          : structVote > 0
            ? "কয়েক মিনিটের হাইয়ার ক্লোজ"
            : "কয়েক মিনিটের লোয়ার ক্লোজ",
    },
  ];

  const weights = [0.28, 0.2, 0.22, 0.18, 0.12];
  const score = factors.reduce((sum, factor, index) => sum + factor.vote * weights[index], 0);
  const direction: Direction = score >= 0 ? "CALL" : "PUT";
  const sign = Math.sign(score) || 1;
  const aligned = factors.filter((factor) => Math.sign(factor.vote) === sign && Math.abs(factor.vote) >= 0.2);
  const confidence = clamp(Math.round(50 + Math.abs(score) * 48), 50, 92);
  const ranked = [...factors].sort((a, b) => Math.abs(b.vote) - Math.abs(a.vote));
  const reason = `${ranked
    .slice(0, 3)
    .map((factor) => factor.note)
    .join("। ")}।`;

  return {
    direction,
    confidence,
    tradable: aligned.length >= 3 && Math.abs(score) >= 0.12,
    reason,
    factors,
  };
}

export function floorMinute(sec: number) {
  return sec - (sec % 60);
}

export function formatClock(ms: number) {
  return new Intl.DateTimeFormat("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).format(new Date(ms));
}

export function formatHM(sec: number) {
  return new Intl.DateTimeFormat("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(new Date(sec * 1000));
}

export function priceDigits(sample: number) {
  const abs = Math.abs(sample);
  if (abs >= 1000) return 2;
  if (abs >= 100) return 3;
  if (abs >= 10) return 4;
  return 5;
}

export function formatPrice(value: number, sample: number) {
  const digits = priceDigits(sample);
  return value.toLocaleString("en-US", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

export function formatPnl(value: number) {
  const sign = value > 0 ? "+" : "";
  return `${sign}${value.toFixed(2)}`;
}

export function isPrintSeries(candles: Candle[]) {
  const recent = candles.slice(-12);
  if (recent.length < 6) return false;
  const flat = recent.filter((candle) => candle.high === candle.low).length;
  return flat / recent.length >= 0.75;
}

function finishTrade(trade: Trade, entry: number, exit: number): Trade {
  const eps = Math.max(Math.abs(entry) * 1e-8, 1e-8);
  let result: TradeResult;
  if (Math.abs(exit - entry) <= eps) result = "draw";
  else if (trade.direction === "CALL") result = exit > entry ? "win" : "loss";
  else result = exit < entry ? "win" : "loss";
  const pnl = result === "win" ? (trade.stake * trade.payoutPct) / 100 : result === "loss" ? -trade.stake : 0;
  return { ...trade, entryPrice: entry, exitPrice: exit, result, pnl };
}

export function settleAgainstBook(trade: Trade, candles: Candle[], nowSec: number, livePrice: number): Trade {
  if (trade.result !== "pending") return trade;
  if (nowSec - trade.entryTime > 180 && !candles.some((candle) => candle.time >= trade.entryTime - 60)) {
    return { ...trade, result: "draw", pnl: 0, signalSent: true, resultSent: true };
  }

  if (isPrintSeries(candles)) {
    const prev = candles.find((candle) => candle.time === trade.entryTime - 60);
    const cur = candles.find((candle) => candle.time === trade.entryTime);
    const entry = prev?.close ?? trade.entryPrice ?? livePrice;
    if (!cur) {
      if (nowSec - trade.entryTime > 180) {
        return { ...trade, entryPrice: entry, result: "draw", pnl: 0, signalSent: true, resultSent: true };
      }
      return { ...trade, entryPrice: entry };
    }
    const ready = candles.some((candle) => candle.time > trade.entryTime) || nowSec >= trade.entryTime + 70;
    if (!ready) return { ...trade, entryPrice: entry };
    return finishTrade(trade, entry, cur.close);
  }

  const cur = candles.find((candle) => candle.time === trade.entryTime);
  if (!cur) {
    if (nowSec - trade.entryTime > 180) {
      return { ...trade, result: "draw", pnl: 0, signalSent: true, resultSent: true };
    }
    return { ...trade, entryPrice: trade.entryPrice ?? livePrice };
  }
  const closed = candles.some((candle) => candle.time > cur.time) || nowSec >= trade.entryTime + 70;
  if (!closed) return { ...trade, entryPrice: cur.open };
  return finishTrade(trade, cur.open, cur.close);
}

export function signalText(trade: Trade) {
  return [
    "EKMIN · 1 MIN",
    trade.label,
    trade.direction,
    `Entry time: ${formatHM(trade.entryTime)}`,
    `Confidence: ${trade.confidence}%`,
    `Reason: ${trade.reason}`,
    "",
    "১ মিনিট পর রেজাল্ট অটো আসবে।",
    "Quotex-এ অর্ডার নিজে দিতে হবে।",
  ].join("\n");
}

export function resultText(trade: Trade) {
  const word = trade.result === "win" ? "WIN" : trade.result === "loss" ? "LOSS" : "DRAW";
  const sample = trade.entryPrice ?? trade.exitPrice ?? 1;
  const entry = trade.entryPrice == null ? "—" : formatPrice(trade.entryPrice, sample);
  const exit = trade.exitPrice == null ? "—" : formatPrice(trade.exitPrice, sample);
  return [
    "EKMIN · RESULT",
    `${trade.label} ${trade.direction}`,
    word,
    `${entry} → ${exit}`,
    trade.pnl == null ? "" : `P/L: ${formatPnl(trade.pnl)}`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function sessionStats(trades: Trade[]) {
  const done = trades.filter((trade) => trade.result !== "pending");
  const wins = done.filter((trade) => trade.result === "win").length;
  const losses = done.filter((trade) => trade.result === "loss").length;
  const draws = done.filter((trade) => trade.result === "draw").length;
  const pnl = done.reduce((sum, trade) => sum + (trade.pnl ?? 0), 0);
  const decided = wins + losses;
  let streak = 0;
  let streakKind: "win" | "loss" | null = null;
  for (const trade of done) {
    if (trade.result !== "win" && trade.result !== "loss") continue;
    if (streakKind == null) {
      streakKind = trade.result;
      streak = 1;
      continue;
    }
    if (trade.result === streakKind) streak += 1;
    else break;
  }
  return {
    wins,
    losses,
    draws,
    pnl,
    rate: decided === 0 ? null : wins / decided,
    streak,
    streakKind,
    decided,
  };
}
