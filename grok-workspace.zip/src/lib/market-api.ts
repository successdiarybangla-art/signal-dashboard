import { createServerFn } from "@tanstack/react-start";
import type { Candle } from "@/lib/candles";
import { pairByYahoo } from "@/lib/pairs";

type MarketOk = {
  ok: true;
  symbol: string;
  candles: Candle[];
  price: number;
  serverNow: number;
};

type MarketFail = { ok: false; error: string };

const cache = new Map<string, { at: number; body: MarketOk }>();

function normalize(raw: unknown): { candles: Candle[]; price: number } | null {
  if (!raw || typeof raw !== "object") return null;
  const chart = (raw as { chart?: { result?: unknown[] } }).chart;
  const result = chart?.result?.[0];
  if (!result || typeof result !== "object") return null;
  const row = result as {
    timestamp?: number[];
    meta?: { regularMarketPrice?: number };
    indicators?: { quote?: Array<Record<string, Array<number | null>>> };
  };
  const times = row.timestamp ?? [];
  const quote = row.indicators?.quote?.[0];
  if (!quote) return null;
  const byTime = new Map<number, Candle>();
  let live = 0;
  let liveAt = 0;
  for (let i = 0; i < times.length; i++) {
    const open = quote.open?.[i];
    const high = quote.high?.[i];
    const low = quote.low?.[i];
    const close = quote.close?.[i];
    if (open == null || high == null || low == null || close == null) continue;
    if (![open, high, low, close].every(Number.isFinite)) continue;
    if (times[i] % 60 !== 0) {
      if (times[i] >= liveAt) {
        live = close;
        liveAt = times[i];
      }
      continue;
    }
    byTime.set(times[i], { time: times[i], open, high, low, close });
  }
  const candles = [...byTime.values()].sort((a, b) => a.time - b.time).slice(-90);
  if (candles.length < 30) return null;
  const meta = row.meta?.regularMarketPrice;
  const price = live || (typeof meta === "number" && Number.isFinite(meta) ? meta : candles[candles.length - 1].close);
  return { candles, price };
}

export const getMarket = createServerFn({ method: "POST" })
  .validator((input: { symbol: string }) => {
    const symbol = input?.symbol;
    if (!pairByYahoo(symbol)) throw new Error("Unknown pair");
    return { symbol };
  })
  .handler(async ({ data }): Promise<MarketOk | MarketFail> => {
    const hit = cache.get(data.symbol);
    const now = Date.now();
    if (hit && now - hit.at < 1500) return hit.body;
    try {
      const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(data.symbol)}?interval=1m&range=1d&includePrePost=true`;
      const response = await fetch(url, {
        headers: {
          "user-agent": "Mozilla/5.0",
          accept: "application/json",
        },
        signal: AbortSignal.timeout(12000),
      });
      if (!response.ok) return { ok: false, error: "মার্কেট ডেটা আসেনি। আবার চেষ্টা হচ্ছে।" };
      const json: unknown = await response.json();
      const parsed = normalize(json);
      if (!parsed) return { ok: false, error: "যথেষ্ট ক্যান্ডেল পাওয়া যায়নি।" };
      const body: MarketOk = {
        ok: true,
        symbol: data.symbol,
        candles: parsed.candles,
        price: parsed.price,
        serverNow: Date.now(),
      };
      cache.set(data.symbol, { at: Date.now(), body });
      return body;
    } catch {
      return { ok: false, error: "মার্কেট ডেটা আসেনি। আবার চেষ্টা হচ্ছে।" };
    }
  });
