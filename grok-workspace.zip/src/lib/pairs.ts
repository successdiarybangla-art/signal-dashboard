export type Pair = {
  id: string;
  label: string;
  yahoo: string;
  kind: string;
};

export const PAIRS: Pair[] = [
  { id: "eurusd", label: "EUR/USD", yahoo: "EURUSD=X", kind: "ফরেক্স" },
  { id: "gbpusd", label: "GBP/USD", yahoo: "GBPUSD=X", kind: "ফরেক্স" },
  { id: "usdjpy", label: "USD/JPY", yahoo: "USDJPY=X", kind: "ফরেক্স" },
  { id: "audusd", label: "AUD/USD", yahoo: "AUDUSD=X", kind: "ফরেক্স" },
  { id: "btcusd", label: "BTC/USD", yahoo: "BTC-USD", kind: "ক্রিপ্টো" },
  { id: "ethusd", label: "ETH/USD", yahoo: "ETH-USD", kind: "ক্রিপ্টো" },
  { id: "gold", label: "Gold", yahoo: "GC=F", kind: "ফিউচার" },
];

const byId = new Map(PAIRS.map((pair) => [pair.id, pair]));
const byYahoo = new Map(PAIRS.map((pair) => [pair.yahoo, pair]));

export function pairById(id: string): Pair {
  return byId.get(id) ?? PAIRS[0];
}

export function pairByYahoo(symbol: string): Pair | undefined {
  return byYahoo.get(symbol);
}
