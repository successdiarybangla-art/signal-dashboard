import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  analyze,
  ENTRY_WINDOW,
  floorMinute,
  isPrintSeries,
  settleAgainstBook,
  type Analysis,
  type Candle,
  type Trade,
} from "@/lib/candles";
import { pairById, type Pair } from "@/lib/pairs";

export type Snap = {
  symbol: string;
  candles: Candle[];
  price: number;
  serverNow: number;
};

type DeskState = {
  pairId: string;
  auto: boolean;
  minConfidence: number;
  stake: number;
  payoutPct: number;
  telegramToken: string;
  telegramChatId: string;
  telegramOn: boolean;
  trades: Trade[];
  snap: Snap | null;
  error: string | null;
  skewMs: number;
  telegramNote: string;
  confirmClear: boolean;
  setPair: (id: string) => void;
  patch: (partial: Partial<Pick<DeskState, "auto" | "minConfidence" | "stake" | "payoutPct" | "telegramToken" | "telegramChatId" | "telegramOn" | "telegramNote" | "confirmClear">>) => void;
  ingest: (snap: Snap) => void;
  tick: () => void;
  takeSignal: () => { ok: true } | { ok: false; error: string };
  markSent: (id: string, kind: "signal" | "result") => void;
  clearTrades: () => void;
};

function sameBook(left: Trade[], right: Trade[]) {
  if (left.length !== right.length) return false;
  for (let i = 0; i < left.length; i++) {
    if (left[i] !== right[i]) return false;
  }
  return true;
}

function bookTrades(trades: Trade[], candles: Candle[], nowSec: number, livePrice: number) {
  return trades.map((trade) => settleAgainstBook(trade, candles, nowSec, livePrice));
}

function openTrade(
  trades: Trade[],
  pair: Pair,
  analysis: Analysis,
  entryTime: number,
  entryPrice: number | null,
  stake: number,
  payoutPct: number,
  notify: boolean,
) {
  if (trades.some((trade) => trade.result === "pending")) return trades;
  if (trades.some((trade) => trade.entryTime === entryTime && trade.pairId === pair.id)) return trades;
  const trade: Trade = {
    id: `${pair.id}-${entryTime}`,
    pairId: pair.id,
    label: pair.label,
    direction: analysis.direction,
    confidence: analysis.confidence,
    reason: analysis.reason,
    entryTime,
    entryPrice,
    exitPrice: null,
    result: "pending",
    stake,
    payoutPct,
    pnl: null,
    notify,
    signalSent: false,
    resultSent: false,
  };
  return [trade, ...trades].slice(0, 180);
}

function maybeAuto(state: DeskState, snap: Snap, nowSec: number) {
  let trades = bookTrades(state.trades, snap.candles, nowSec, snap.price);
  if (!state.auto) return trades;
  const currentStart = floorMinute(nowSec);
  const second = nowSec - currentStart;
  if (second > ENTRY_WINDOW) return trades;
  if (snap.serverNow < currentStart * 1000) return trades;
  if (snap.symbol !== pairById(state.pairId).yahoo) return trades;
  const latest = snap.candles[snap.candles.length - 1];
  if (!latest || nowSec - latest.time > 180) return trades;
  const closed = snap.candles.filter((candle) => candle.time < currentStart);
  const analysis = analyze(closed);
  if (!analysis || !analysis.tradable || analysis.confidence < state.minConfidence) return trades;
  const forming = snap.candles.find((candle) => candle.time === currentStart);
  const prev = snap.candles.find((candle) => candle.time === currentStart - 60);
  const entryPrice = isPrintSeries(snap.candles) ? (prev?.close ?? snap.price) : (forming?.open ?? snap.price);
  return openTrade(
    trades,
    pairById(state.pairId),
    analysis,
    currentStart,
    entryPrice,
    state.stake,
    state.payoutPct,
    state.telegramOn && state.telegramToken.trim() !== "" && state.telegramChatId.trim() !== "",
  );
}

export const useDesk = create<DeskState>()(
  persist(
    (set, get) => ({
      pairId: "eurusd",
      auto: true,
      minConfidence: 62,
      stake: 1,
      payoutPct: 80,
      telegramToken: "",
      telegramChatId: "",
      telegramOn: false,
      trades: [],
      snap: null,
      error: null,
      skewMs: 0,
      telegramNote: "",
      confirmClear: false,
      setPair: (id) => set({ pairId: pairById(id).id, snap: null, error: null }),
      patch: (partial) =>
        set((state) => ({
          ...partial,
          minConfidence:
            partial.minConfidence == null
              ? state.minConfidence
              : Math.round(Math.min(90, Math.max(50, partial.minConfidence))),
          stake:
            partial.stake == null
              ? state.stake
              : Number.isFinite(partial.stake) && partial.stake > 0
                ? Math.min(partial.stake, 100000)
                : state.stake,
          payoutPct:
            partial.payoutPct == null
              ? state.payoutPct
              : Number.isFinite(partial.payoutPct)
                ? Math.min(100, Math.max(1, Math.round(partial.payoutPct)))
                : state.payoutPct,
        })),
      ingest: (snap) =>
        set((state) => {
          const skewMs = snap.serverNow - Date.now();
          const nowSec = Math.floor(snap.serverNow / 1000);
          return {
            snap,
            skewMs,
            error: null,
            trades: maybeAuto(state, snap, nowSec),
          };
        }),
      tick: () =>
        set((state) => {
          if (!state.snap) return state;
          const nowSec = Math.floor((Date.now() + state.skewMs) / 1000);
          const age = Date.now() + state.skewMs - state.snap.serverNow;
          if (age > 20000) return state;
          const trades = maybeAuto(state, state.snap, nowSec);
          if (sameBook(trades, state.trades)) return state;
          return { trades };
        }),
      takeSignal: () => {
        const state = get();
        if (!state.snap) return { ok: false, error: "দাম এখনো আসেনি" };
        const nowSec = Math.floor((Date.now() + state.skewMs) / 1000);
        const currentStart = floorMinute(nowSec);
        const second = nowSec - currentStart;
        if (second > ENTRY_WINDOW) return { ok: false, error: "এন্ট্রি উইন্ডো শেষ। পরের মিনিট নাও।" };
        if (state.snap.serverNow < currentStart * 1000) {
          return { ok: false, error: "এই মিনিটের দাম এখনো লক হয়নি" };
        }
        const latest = state.snap.candles[state.snap.candles.length - 1];
        if (!latest || nowSec - latest.time > 180) {
          return { ok: false, error: "এই পেয়ারে লাইভ ক্যান্ডেল নেই" };
        }
        if (state.trades.some((trade) => trade.result === "pending")) {
          return { ok: false, error: "আগের ট্রেড এখনো চলছে" };
        }
        const pair = pairById(state.pairId);
        const closed = state.snap.candles.filter((candle) => candle.time < currentStart);
        const analysis = analyze(closed);
        if (!analysis) return { ok: false, error: "সিগন্যাল বের হয়নি" };
        const forming = state.snap.candles.find((candle) => candle.time === currentStart);
        const prev = state.snap.candles.find((candle) => candle.time === currentStart - 60);
        const entryPrice = isPrintSeries(state.snap.candles)
          ? (prev?.close ?? state.snap.price)
          : (forming?.open ?? state.snap.price);
        set({
          trades: openTrade(
            state.trades,
            pair,
            analysis,
            currentStart,
            entryPrice,
            state.stake,
            state.payoutPct,
            state.telegramOn && state.telegramToken.trim() !== "" && state.telegramChatId.trim() !== "",
          ),
        });
        return { ok: true };
      },
      markSent: (id, kind) =>
        set((state) => ({
          trades: state.trades.map((trade) =>
            trade.id !== id
              ? trade
              : kind === "signal"
                ? { ...trade, signalSent: true }
                : { ...trade, resultSent: true },
          ),
        })),
      clearTrades: () => set({ trades: [], confirmClear: false }),
    }),
    {
      name: "ekmin-desk",
      skipHydration: true,
      partialize: (state) => ({
        pairId: state.pairId,
        auto: state.auto,
        minConfidence: state.minConfidence,
        stake: state.stake,
        payoutPct: state.payoutPct,
        telegramToken: state.telegramToken,
        telegramChatId: state.telegramChatId,
        telegramOn: state.telegramOn,
        trades: state.trades,
      }),
    },
  ),
);

export function readPreview(snap: Snap | null, nowSec: number): Analysis | null {
  if (!snap) return null;
  const currentStart = floorMinute(nowSec);
  const closed = snap.candles.filter((candle) => candle.time < currentStart);
  return analyze(closed.length >= 30 ? closed : snap.candles.slice(0, -1));
}

export function marketIsStale(snap: Snap | null, nowSec: number) {
  if (!snap) return false;
  const latest = snap.candles[snap.candles.length - 1];
  return !latest || nowSec - latest.time > 180;
}
