import { createServerFn } from "@tanstack/react-start";

type Ok = { ok: true; chatId?: string; bot?: string };
type Fail = { ok: false; error: string };

function cleanToken(token: string) {
  const value = token.trim();
  if (!/^\d{6,12}:[A-Za-z0-9_-]{20,}$/.test(value)) return null;
  return value;
}

function cleanChat(chatId: string) {
  const value = chatId.trim();
  if (!/^-?\d{1,20}$/.test(value)) return null;
  return value;
}

async function telegram(token: string, method: string, body?: Record<string, string>) {
  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: body ? "POST" : "GET",
    headers: body ? { "content-type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(12000),
  });
  const json = (await response.json()) as {
    ok?: boolean;
    description?: string;
    result?: unknown;
  };
  return json;
}

export const sendTelegram = createServerFn({ method: "POST" })
  .validator((input: { token: string; chatId: string; text: string }) => {
    const token = cleanToken(input?.token ?? "");
    const chatId = cleanChat(input?.chatId ?? "");
    const text = (input?.text ?? "").slice(0, 3500);
    if (!token) throw new Error("টোকেন ঠিক না");
    if (!chatId) throw new Error("চ্যাট আইডি ঠিক না");
    if (!text) throw new Error("খালি মেসেজ");
    return { token, chatId, text };
  })
  .handler(async ({ data }): Promise<Ok | Fail> => {
    try {
      const json = await telegram(data.token, "sendMessage", {
        chat_id: data.chatId,
        text: data.text,
      });
      if (!json.ok) {
        return { ok: false, error: json.description || "টেলিগ্রাম পাঠায়নি" };
      }
      return { ok: true };
    } catch {
      return { ok: false, error: "টেলিগ্রামে পৌঁছায়নি" };
    }
  });

export const findTelegramChat = createServerFn({ method: "POST" })
  .validator((input: { token: string }) => {
    const token = cleanToken(input?.token ?? "");
    if (!token) throw new Error("টোকেন ঠিক না");
    return { token };
  })
  .handler(async ({ data }): Promise<Ok | Fail> => {
    try {
      const me = await telegram(data.token, "getMe");
      if (!me.ok) return { ok: false, error: "টোকেন মানা হয়নি। BotFather থেকে নতুন করে নাও।" };
      const bot =
        me.result && typeof me.result === "object" && "username" in me.result
          ? String((me.result as { username?: string }).username ?? "")
          : "";
      const updates = await telegram(data.token, "getUpdates");
      const list = Array.isArray(updates.result) ? updates.result : [];
      let chatId = "";
      for (let i = list.length - 1; i >= 0; i--) {
        const item = list[i] as {
          message?: { chat?: { id?: number } };
          edited_message?: { chat?: { id?: number } };
        };
        const id = item.message?.chat?.id ?? item.edited_message?.chat?.id;
        if (typeof id === "number") {
          chatId = String(id);
          break;
        }
      }
      if (!chatId) {
        return {
          ok: false,
          error: bot
            ? `@${bot} কে একটা মেসেজ পাঠাও, তারপর আবার চাপো।`
            : "বটকে আগে একটা মেসেজ পাঠাও।",
        };
      }
      return { ok: true, chatId, bot };
    } catch {
      return { ok: false, error: "টেলিগ্রামে পৌঁছায়নি" };
    }
  });
